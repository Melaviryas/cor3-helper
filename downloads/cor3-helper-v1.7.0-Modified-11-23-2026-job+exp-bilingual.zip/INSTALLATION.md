# COR3 Helper — Modified 11/23/2026 (English / 简体中文)

## 安装／更新

1. 解压 ZIP。在 chrome://extensions 开启“开发者模式”。
2. 加载已解压的扩展程序时，选择本包内的 **extension** 文件夹。
3. 更新已有安装时，将 extension 文件夹的内容覆盖到原扩展目录，在 Chrome 扩展页点击“重新加载”，再刷新 cor3.gg。
4. 在顶部 **Language / 语言** 选择 English 或简体中文；会自动保存并同步到弹窗、侧边栏、独立窗口及 DevTools 页面。

首次使用默认英文。切换语言不会改变远征出售模式、派遣设置或 AutoJobs 配置。游戏专有名称和原始通信数据保留原文；游戏本身的语言与扩展语言相互独立。

## Install / update

1. Extract the ZIP and enable Developer mode at chrome://extensions.
2. Choose this package's **extension** folder with “Load unpacked”.
3. To update an existing installation, copy the contents of extension into its original folder, reload the extension, then refresh cor3.gg.
4. Select English or 简体中文 using **Language / 语言** at the top. Your choice is saved and shared by extension windows.

English is the initial default. Language changes preserve selling, dispatch and AutoJobs settings. Game proper names and raw protocol data retain their original text.

## Contents / 文件

- extension/: ready-to-load extension / 可直接加载的扩展。
- source/: editable source, tests and build files / 源码、测试与构建文件。
- README.md and readme-zh.md: concise English and Chinese fork introductions, including AI disclosure / 简短的中英文分支说明与 AI 声明。
- changes.patch: changes against upstream v1.7.0 / 相对上游 v1.7.0 的补丁。
- validation/: build/test reports and DOM checks / 构建、测试报告与界面检查脚本。

## Validation / 验证

109 automated tests passed. DOM checks cover English/Chinese round trips in popup, popout and side panel; saved language, cross-window sync, dynamic market/loadout/expedition text, exclusive selling modes, and preservation of raw WS data and automation settings. The six solver/seller engine scripts are byte-identical to the preceding job+exp version. No live game session was tested for this bilingual update.

109 项自动化测试通过。界面检查覆盖弹窗、独立窗口与侧边栏的双语切换、语言保存、跨窗口同步、市场／配置／远征动态内容、出售模式互斥，以及通信数据和自动化设置保持不变。六个任务／出售／小游戏核心脚本与上一个 job+exp 版本完全相同。本次双语更新未进行实际游戏会话测试。

Build source / 构建源码: `cd source`, `npm ci`, `npm run build`.
Run unit tests / 运行单元测试: `node --test tests/*.test.cjs tests/*.test.mjs` from source/.
DOM checks in validation/ require linkedom 0.18.15 and source/'s esbuild dev dependency; use COR3_SOURCE_ROOT to choose a different source directory.
