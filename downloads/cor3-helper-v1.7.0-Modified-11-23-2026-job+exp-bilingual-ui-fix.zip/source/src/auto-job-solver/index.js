// Auto Job Solver — thin entry point.
// Imports all submodules so esbuild bundles them into a single IIFE.

import { state, sendCmd, log } from './state.js';
import { processQueue } from './main-loop.js';

(function () {
    // ---- Listen for start/stop commands ----
    window.addEventListener('message', function (event) {
        if (event.source !== window) return;

        if (event.data && event.data.type === 'COR3_AUTOJOB_START') {
            if (state.running) { log('Auto Job Solver already running — ignoring duplicate start', 'warn'); return; }
            state.abortFlag = false;
            state.pendingLoadoutMode = null;
            state.jobQueue = event.data.jobs || [];
            state.solverSettings = event.data.settings || {};
            processQueue();
        }

        if (event.data?.type === 'COR3_AUTOJOB_LOADOUT_MODE') {
            const value = event.data.mode === 'software' ? 'software' : 'auto';
            if (state.running) state.pendingLoadoutMode = value;
            else state.solverSettings.loadoutMode = value;
        }

        if (event.data && event.data.type === 'COR3_AUTOJOB_STOP') {
            state.abortFlag = true;
            log('Stop signal received — aborting after current step', 'warn');
        }
    });

    console.log('[COR3 Helper] Auto Job Solver engine loaded');
})();
