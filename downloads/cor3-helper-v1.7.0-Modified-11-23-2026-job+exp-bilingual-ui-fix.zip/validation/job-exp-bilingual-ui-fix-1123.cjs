const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {parseHTML}=require('linkedom');const root=process.env.COR3_SOURCE_ROOT||path.resolve(__dirname,'../source');
const settle=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{for(const mode of ['', 'popout', 'sidepanel']){
 const {window,document}=parseHTML(fs.readFileSync(root+'/dist/popup.html','utf8'));
 const proto=window.HTMLSelectElement.prototype,descriptor=Object.getOwnPropertyDescriptor(proto,'value');if(!descriptor.set)Object.defineProperty(proto,'value',{...descriptor,get(){return descriptor.get.call(this)??this.querySelector('option')?.value},set(value){for(const option of this.querySelectorAll('option'))option.selected=option.value===value}});
 window.location={search:mode?'?mode='+mode:'',href:'chrome-extension://test/popup.html'};window.matchMedia=()=>({matches:false,addEventListener(){}});
 const errors=[],listeners=[],sent=[],writes=[],copied=[];
 const local={expeditionsData:[{id:'e',status:'RUNNING',mercenary:{id:'zero',callsign:'Zero'},locationName:'Skylift Remains',zoneName:'Surface',endTime:new Date(Date.now()+1800000).toISOString(),messages:[{id:'d',decisionOptions:[{id:'safe',label:'Wait',riskModifier:-1,lootModifier:1}],decisionDeadline:new Date(Date.now()+60000).toISOString()}]}],
  expeditionsDataUpdatedAt:Date.now(),mercDebugLogs:[{timestamp:new Date().toISOString(),msg:'派遣已确认',level:'success'}],
  stashData:{items:[],maxCapacity:360,currentUsage:0},mercenariesData:{mercenaries:[{id:'zero',callsign:'Zero',status:'AVAILABLE'}]},mercConfigData:{zero:{totalCost:1995}},
  periodicMercNextCheckAt:Date.now()+1800000,expeditionSaleStatus:{message:'出售完成'}};
 Object.assign(local,{marketData:{market:{marketName:'CORE Market'},reputation:{level:5,progress:5000,requiredReputation:15000,isLevelLocked:false,isMaxLevel:false},userCredits:43722,nextJobsResetAt:new Date(Date.now()+3600000).toISOString(),jobs:[],lots:[]},loadoutData:{equippedHardware:{cpu:{id:'cpu',name:'UNO 6.651',category:'CPU',specs:{cpuFrequency:6,cpuCores:16}}},ownedHardware:[],equippedSoftware:[{id:'09',name:'5CRYPt0L 09',specs:[{type:'DECRYPT',power:[14,38],fileTypes:['.eb54x']}],consuming:{}}],ownedSoftware:[],resources:{supply:{cpu_frequency:6,cpu_cores:16},demand:{cpu_frequency:3,cpu_cores:4},softwarePower:[]}}});
 const sync={uiLanguage:'zh-CN',expeditionModuleEnabled:true,expeditionSaleMode:'non-drone',autoSendMerc:{enabled:true,maxMercCost:3000},periodicMercDispatchEnabled:true,
  autoJobSolverEnabled:true,autoJobLoadoutMode:'software',autoClaimExpeditionMail:true};

 Object.assign(sync,{pinnedTimers:{home_jobs:true,dark_jobs:true,soyuz_jobs:true,usol_jobs:true},autoRefresh:{}});
 Object.assign(local,{stashData:{items:[{id:'wrench',itemConfigId:'custom-wrench',name:'SPI Smartwrench',tier:'RARE',canSell:true,sellPrice:8107,canCraft:true,description:'Original item description',imageUrl:'https://cdn.cor3.gg/test-wrench.png'},{id:'chip',name:'TX-71 board',tier:'COMMON',canSell:true,sellPrice:1320,description:'Board description',imageUrl:'https://cdn.cor3.gg/test-chip.png'}],maxCapacity:360,currentUsage:2}});
 for(const[key,name]of [['darkMarketData','BMI-ZEN Market'],['soyuzMarketData','SOYUZ RM7 Market'],['usolMarketData','USOL RM7 Market']])local[key]={...local.marketData,market:{marketName:name}};
 const area=(store,name)=>({get(keys,cb){const r=keys===null?{...store}:Object.fromEntries((typeof keys==='string'?[keys]:Array.isArray(keys)?keys:Object.keys(keys||{})).map(k=>[k,store[k]??(typeof keys==='object'&&!Array.isArray(keys)?keys[k]:undefined)]));cb?.(r);return Promise.resolve(r)},set(v,cb){const changes={};for(const [k,value]of Object.entries(v)){if(JSON.stringify(store[k])!==JSON.stringify(value))changes[k]={oldValue:store[k],newValue:value};store[k]=value}writes.push({name,v});if(Object.keys(changes).length)for(const fn of listeners)fn(changes,name);cb?.();return Promise.resolve()},remove(){return Promise.resolve()}});
 const chrome={storage:{sync:area(sync,'sync'),local:area(local,'local'),onChanged:{addListener(fn){listeners.push(fn)},removeListener(){}}},runtime:{id:'test',getURL:p=>p,getManifest:()=>({version:'1.7.0'}),sendMessage(){return Promise.resolve({})},onMessage:{addListener(){}}},tabs:{query:async()=>[{id:7}],sendMessage:async(id,m)=>{sent.push(m);return {success:true,message:'已请求检查'}},create:async()=>({})},windows:{getCurrent:async()=>({width:1200,height:800}),create:async()=>({})},sidePanel:{setOptions:async()=>{},open:async()=>{}}};
 const context={window,document,chrome,console:{log(){},warn(){},error(...a){errors.push(a.join(' '))}},Node:window.Node,DOMParser:class {parseFromString(html){return parseHTML("<html><body>"+html+"</body></html>").document}},navigator:{clipboard:{writeText:async s=>copied.push(s)}},URLSearchParams,URL,Date,MutationObserver:window.MutationObserver,setTimeout(){return 1},clearTimeout(){},setInterval(){return 1},clearInterval(){},fetch:async()=>({ok:false,json:async()=>({})}),cor3LogError(...a){errors.push(a.join(' '))}};
 vm.runInNewContext(fs.readFileSync(root+'/dist/popup.js','utf8'),context);await settle();assert.deepEqual(errors,[]);
 const exp=document.getElementById('expeditionsSection'),active=document.getElementById('activeExpeditionSection'),merc=document.getElementById('mercenariesSection');
 assert.ok(exp);assert.equal(active.contains(document.getElementById('decisionsSection')),false);assert.equal(active.contains(document.getElementById('mercDebugConsole')),false);
 assert.equal(active.nextElementSibling.id,'decisionsSection');assert.equal(active.nextElementSibling.nextElementSibling.id,'expeditionDebugSection');assert.equal(document.getElementById('personalDroneSection'),null);assert.equal(merc.contains(document.getElementById('expeditionSellingSection')),false);
 assert.equal(merc.contains(document.getElementById('mercDebugConsole')),false);
 assert.equal(exp.querySelectorAll('.exp-sale-choice').length,4);
 for(const text of ['不自动出售。','腾够空间即停止。','保留全部无人机材料。','包括无人机材料。'])assert.ok(exp.textContent.includes(text),text);
 const ordered=[...document.querySelectorAll('[id]')].map(el=>el.id);assert.ok(ordered.indexOf('marketsGroupToggle')<ordered.indexOf('expeditionsSection'));
 assert.ok(ordered.indexOf('expeditionsSection')<ordered.indexOf('loadoutGroupToggle'));
 if(mode){assert.equal(exp.parentElement.className,'popout-card');assert.ok(exp.contains(merc),'no split of expedition children');}
 assert.ok(document.getElementById('expeditionSummary').textContent.includes('Zero'));
 for(const value of ['all','full','non-drone','off']){
  const input=document.getElementById('expSale_'+value);input.checked=true;input.dispatchEvent(new window.Event('change'));await settle();
  assert.equal(sync.expeditionSaleMode,value);
  assert.equal([...exp.querySelectorAll('[id^=expSale_]')].filter(input=>input.checked).length,1);
  assert.equal(document.getElementById('expeditionSaleModeBadge').textContent.includes(({all:'全出售',full:'仓库满出售','non-drone':'出售非无人机',off:'关闭'})[value]),true);
 }
 const all=document.getElementById('expSale_all');all.checked=true;all.dispatchEvent(new window.Event('change'));await settle();all.checked=false;all.dispatchEvent(new window.Event('change'));await settle();assert.equal(sync.expeditionSaleMode,'off');assert.equal(document.getElementById('expSale_off').checked,true);
 document.getElementById('expeditionsGroupToggle').dispatchEvent(new window.Event('click'));assert.ok(document.getElementById('expeditionGroupBody').classList.contains('section-group-hidden'));
 assert.ok(!document.getElementById('expeditionSummary').classList.contains('section-group-hidden'));
 const master=document.getElementById('expeditionModuleToggle');master.checked=false;master.dispatchEvent(new window.Event('change'));await settle();
 assert.equal(sync.autoJobSolverEnabled,true);assert.equal(sync.autoJobLoadoutMode,'software');assert.equal(sync.autoSendMerc.enabled,true);assert.ok(document.getElementById('expeditionSaleModeBadge').textContent.includes('已暂停'));
 assert.equal(sync.periodicMercDispatchEnabled,true);assert.equal(document.getElementById('expeditionCheckNowBtn').disabled,true);
 master.checked=true;master.dispatchEvent(new window.Event('change'));await settle();document.getElementById('expeditionCheckNowBtn').dispatchEvent(new window.Event('click'));await settle();assert.equal(sent.at(-1).action,'expeditionCheckNow');
 document.getElementById('copyMercLogsBtn').dispatchEvent(new window.Event('click'));await settle();assert.ok(copied[0].includes('派遣已确认'));
 const actions=[...document.getElementById('autoJobSolverSection').querySelector('.section-title').querySelectorAll('button')].map(b=>b.id);assert.deepEqual(actions,['dismissAllFailedJobsBtn','copyAllLogsBtn','refreshAutoJobsBtn']);
 assert.ok(document.getElementById('modifiedVersionNote').textContent.includes('11/23/2026'));assert.deepEqual(errors,[]);


 const inventory=document.getElementById('inventorySection');
 assert.ok(inventory.hasAttribute('data-i18n-skip'));assert.equal(inventory.querySelectorAll('.item-card').length,2);assert.equal(inventory.querySelectorAll('.item-card img').length,2);
 assert.ok(inventory.textContent.includes('Inventory'));assert.ok(inventory.textContent.includes('CRAFT'));assert.ok(!inventory.textContent.includes('可售物品按当前'));
 const invHeader=document.getElementById('inventorySectionToggle');invHeader.dispatchEvent(new window.Event('click'));assert.ok(document.getElementById('inventorySectionBody').classList.contains('open'));
 inventory.querySelector('.inv-info-btn').dispatchEvent(new window.Event('click'));assert.ok(document.getElementById('inventoryInfoPopup').classList.contains('open'));assert.ok(document.getElementById('inventoryInfoPopup').textContent.includes('Original item description'));
 const sell=inventory.querySelector('.sell-btn');sell.dispatchEvent(new window.Event('click'));await settle();assert.equal(sell.textContent,'✓ Confirm');sell.dispatchEvent(new window.Event('click'));await settle();assert.equal(sent.at(-1).action,'expeditionManualSell');assert.equal(sent.at(-1).itemId,'wrench');
 const firstSummary=active.nextElementSibling;active.open=false;assert.equal(firstSummary.parentElement.id,'expeditionGroupBody');assert.equal(document.getElementById('expeditionDebugSection').parentElement.id,'expeditionGroupBody');
 for(const text of [...document.querySelectorAll('.pinned-timer-label')].map(n=>n.textContent))assert.ok(!/[分秒]/.test(text),text);
 for(const text of [...document.querySelectorAll('.pinned-timer-value, .home-reset-timer, .dark-reset-timer, .soyuz-reset-timer, .usol-reset-timer')].map(n=>n.textContent)){assert.ok(!/[分秒]/.test(text),text);}
 const beforeSettings=JSON.stringify({...sync,uiLanguage:undefined});
 const picker=document.getElementById('uiLanguageSelect');picker.value='en';picker.dispatchEvent(new window.Event('change'));await settle();
 assert.equal(sync.uiLanguage,'en');assert.equal(document.documentElement.lang,'en');
 assert.ok(document.getElementById('marketContainer').textContent.includes('Reputation — Level 5'),document.getElementById('marketContainer').textContent);
 assert.ok(document.getElementById('loadoutHwContainer').textContent.includes('UNO 6.651'));
 assert.ok(document.getElementById('loadoutSwContainer').textContent.includes('5CRYPt0L 09'));
 assert.ok(exp.textContent.includes('When Stash Is Full'));assert.ok(exp.textContent.includes('Auto-claim expedition reward mail'));
 assert.equal(/[\u3400-\u9fff]/.test(exp.textContent),false,exp.textContent);
 assert.ok(document.getElementById('autoJobsStartBtn').textContent.includes('Start Auto Jobs'));
 await chrome.storage.local.set({expeditionModuleStatus:{phase:'mercenaries',message:'暂无符合费用与筛选条件的可用佣兵，等待下次检查'}});await settle();
 assert.ok(document.getElementById('expeditionSummary').textContent.includes('No available mercenary'));
 picker.value='zh-CN';picker.dispatchEvent(new window.Event('change'));await settle();
 assert.ok(document.getElementById('marketContainer').textContent.includes('声望 — 等级 5'));assert.ok(document.getElementById('loadoutHwContainer').textContent.includes('频率 GHz'),document.getElementById('loadoutHwContainer').textContent);
 assert.ok(document.getElementById('autoJobsStartBtn').textContent.includes('开始自动任务'));
 assert.equal(JSON.stringify({...sync,uiLanguage:undefined}),beforeSettings,'only locale preference changes');
 assert.deepEqual(errors,[]);
 console.log('PASS '+(mode||'popup')+': independent Active/Decisions/Debug panels, no drone assembly, original English inventory cards/images/info/confirmed sale, bilingual round trip, preserved timer tokens and job settings');
}})().catch(error=>{console.error(error);process.exitCode=1});
