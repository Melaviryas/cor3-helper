const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const {parseHTML}=require('linkedom'),esbuild=require('../source/node_modules/esbuild');
(async()=>{
 const root=process.env.COR3_SOURCE_ROOT||path.resolve(__dirname,'../source');const {window,document}=parseHTML(fs.readFileSync(root+'/src/html/popup.html','utf8'));
 const prefs={},handlers=[],packets=[];window.postMessage=p=>packets.push(p);
 const select=document.getElementById('autoJobLoadoutMode');
 // Linkedom's select value is getter-only in some builds; emulate the native setter.
 Object.defineProperty(select,'value',{configurable:true,get(){return this.querySelector('option[selected]')?.getAttribute('value')||this.querySelector('option')?.getAttribute('value')},set(value){this.querySelectorAll('option').forEach(o=>{if(o.getAttribute('value')===value)o.setAttribute('selected','');else o.removeAttribute('selected')})}});
 const chrome={storage:{sync:{get(key,cb){cb({[key]:prefs[key]})},set(values){Object.assign(prefs,values);for(const fn of handlers)fn(Object.fromEntries(Object.entries(values).map(([key,value])=>[key,{newValue:value}])),'sync')}},onChanged:{addListener(fn){handlers.push(fn)}}}};
 const code=(await esbuild.build({stdin:{contents:"import './src/popup/auto-job-loadout-ui.js';import './src/content/auto-job-loadout-settings.js';",resolveDir:root},bundle:true,write:false,format:'iife'})).outputFiles[0].text;
 vm.runInNewContext(code,{window,document,chrome});assert.equal(select.value,'auto');assert.match(document.getElementById('autoJobLoadoutModeHint').textContent,/hardware/);
 select.value='software';select.dispatchEvent(new window.Event('change'));assert.equal(prefs.autoJobLoadoutMode,'software');assert.equal(packets.at(-1).mode,'software');assert.match(document.getElementById('autoJobLoadoutModeHint').textContent,/Hardware stays unchanged/);
 chrome.storage.sync.set({autoJobLoadoutMode:'auto'});assert.equal(select.value,'auto');assert.equal(packets.at(-1).mode,'auto');
 console.log('PASS Loadout mode UI: default joint optimization, persisted software-only mode, live content transport, cross-window updates');
})().catch(e=>{console.error(e);process.exitCode=1});
